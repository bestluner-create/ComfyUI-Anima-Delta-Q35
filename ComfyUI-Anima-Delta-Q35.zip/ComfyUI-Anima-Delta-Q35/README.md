# ComfyUI-Anima-Delta-Q35

Install next to `ComfyUI-Anima-Delta-Mix` in `ComfyUI/custom_nodes/`.
Requires `comfyui-anima-3-8B` (MIT) installed — this pack imports it at runtime and does not vendor that source.

Menu: **Anima Delta Mix**

| Canvas | Class id |
|---|---|
| DeltaMix Q35 Extract Connector | `AnimaQ35Extract` |
| DeltaMix Q35 Attach | `AnimaQ35Attach` |
| DeltaMix Q35 Prompt | `AnimaQ35Prompt` |
| Prompt Text Delta | `PromptTextDelta` |
| Prompt Dual Delta | `PromptDualDelta` |

## Graph

```
UNETLoader (3.8 bake)
    → DeltaMix Q35 Attach (sidecar or Anima 3.8B v1.1 bundle)
    → DeltaMix Q35 Prompt ← Qwen 0.6B + Qwen 3.5 4B
    → Sampler
```

Extract writes `net.anima_v2_connector.*` from the v1.1 bundle into a sidecar.
Attach puts those tensors on `diffusion_model.anima_v2_connector`.
Prompt encodes both text encoders for a MODEL that already has the connector.

## Credits

- CircleStone Labs — Anima
- lylogummy — Anima 3.8B v1.1 chassis and Semantic Connector v2
- GumGum10 — comfyui-anima-3-8B (MIT, runtime dependency)
- Delta Mix — extract / attach / prompt glue
