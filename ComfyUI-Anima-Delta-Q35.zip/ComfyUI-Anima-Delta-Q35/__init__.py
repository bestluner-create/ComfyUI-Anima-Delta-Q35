from .nodes_attach import AnimaQ35Attach
from .nodes_extract import AnimaQ35Extract
from .nodes_prompt import AnimaQ35Prompt
from .nodes_text import PromptDualDelta, PromptTextDelta

NODE_CLASS_MAPPINGS = {
    "AnimaQ35Extract": AnimaQ35Extract,
    "AnimaQ35Attach": AnimaQ35Attach,
    "AnimaQ35Prompt": AnimaQ35Prompt,
    "PromptTextDelta": PromptTextDelta,
    "PromptDualDelta": PromptDualDelta,
}

NODE_DISPLAY_NAME_MAPPINGS = {
    "AnimaQ35Extract": "DeltaMix Q35 Extract Connector",
    "AnimaQ35Attach": "DeltaMix Q35 Attach",
    "AnimaQ35Prompt": "DeltaMix Q35 Prompt",
    "PromptTextDelta": "Prompt Text Delta",
    "PromptDualDelta": "Prompt Dual Delta",
}

for _cls in NODE_CLASS_MAPPINGS.values():
    if getattr(_cls, "CATEGORY", "").startswith("Anima Q35"):
        _cls.CATEGORY = "Anima Delta Mix"

__all__ = ["NODE_CLASS_MAPPINGS", "NODE_DISPLAY_NAME_MAPPINGS"]
