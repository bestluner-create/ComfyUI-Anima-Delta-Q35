from __future__ import annotations

import logging
import os

from safetensors import SafetensorError, safe_open

import comfy.model_management
import comfy.ops
import comfy.utils
import folder_paths

from .official_bridge import official_modules

logger = logging.getLogger(__name__)
PREFIX = "net.anima_v2_connector."


def _connector_files():
    out = []
    for name in folder_paths.get_filename_list("diffusion_models"):
        if not name.lower().endswith(".safetensors"):
            continue
        path = folder_paths.get_full_path("diffusion_models", name)
        if not path or not os.path.isfile(path):
            continue
        try:
            with safe_open(path, framework="pt", device="cpu") as f:
                keys = f.keys()
                meta = f.metadata() or {}
        except (OSError, ValueError, SafetensorError):
            continue
        if meta.get("architecture") == "anima_v2_connector_sidecar":
            out.append(name)
        elif any(k.startswith(PREFIX) or "anima_v2_connector." in k for k in keys):
            out.append(name)
    return sorted(out) or ["anima_v2_connector_only.safetensors"]


def _connector_state(path: str) -> tuple[dict, dict]:
    state, metadata = comfy.utils.load_torch_file(path, return_metadata=True)
    metadata = metadata or {}
    prefix = metadata.get("anima_v2_connector_prefix", PREFIX)
    conn = {}
    for name, tensor in state.items():
        if name.startswith(prefix):
            conn[name[len(prefix):]] = tensor
        elif "anima_v2_connector." in name:
            conn[name.split("anima_v2_connector.", 1)[-1]] = tensor
    if not conn:
        raise RuntimeError(f"No connector tensors in {path}")
    return conn, metadata


class AnimaQ35Attach:
    @classmethod
    def INPUT_TYPES(cls):
        return {
            "required": {
                "model": ("MODEL",),
                "connector": (_connector_files(),),
            }
        }

    RETURN_TYPES = ("MODEL", "STRING")
    RETURN_NAMES = ("model", "log")
    FUNCTION = "attach"
    CATEGORY = "Anima Delta Mix"
    DESCRIPTION = (
        "Attaches Semantic Connector v2 tensors onto an Anima 3.8 MODEL. "
        "Requires comfyui-anima-3-8B installed (MIT, runtime import)."
    )

    def attach(self, model, connector):
        off = official_modules()
        path = folder_paths.get_full_path("diffusion_models", connector)
        if path is None or not os.path.isfile(path):
            raise FileNotFoundError(connector)

        cloned = model.clone()
        base = cloned.model
        dit = getattr(base, "diffusion_model", None)
        native = getattr(dit, "llm_adapter", None)
        if native is None or len(getattr(native, "blocks", [])) != 6:
            raise RuntimeError("MODEL is not Anima 3.8 (llm_adapter / 6 blocks missing).")

        conn_state, metadata = _connector_state(path)
        ops = base.model_config.custom_operations
        if ops is None:
            ops = comfy.ops.pick_operations(
                base.get_dtype(),
                base.manual_cast_dtype,
                fp8_optimizations=base.model_config.optimizations.get("fp8", False),
                model_config=base.model_config,
            )

        cfg = {
            "num_queries": 64,
            "resampler_blocks": 6,
            "resampler_dim": 2048,
            "resampler_heads": 16,
            "mlp_hidden_dim": 5632,
            "initialize_from_native": False,
            "register_native_adapter": False,
            "initialize_resampler": False,
        }
        adapter_meta = {
            k[len("anima_v2_adapter_"):]: v
            for k, v in metadata.items()
            if k.startswith("anima_v2_adapter_")
        }
        if adapter_meta:
            mapping = {
                "semantic_query_tokens": "num_queries",
                "semantic_resampler_blocks": "resampler_blocks",
                "semantic_resampler_dim": "resampler_dim",
                "semantic_resampler_heads": "resampler_heads",
                "semantic_resampler_mlp_hidden_dim": "mlp_hidden_dim",
            }
            for src, dst in mapping.items():
                if src in adapter_meta:
                    cfg[dst] = int(adapter_meta[src])

        connector_mod = off["connector_cls"](
            native_adapter=native,
            semantic_source_dim=2560,
            layer_indices=off["layer_indices"],
            operations=ops,
            **cfg,
        )
        connector_mod.load_trainable_state_dict(conn_state, assign=cloned.is_dynamic())
        connector_mod.eval().requires_grad_(False)
        connector_mod._anima_v2_model_managed = True
        connector_mod._anima_v2_bundle_path = path
        dit.add_module("anima_v2_connector", connector_mod)
        comfy.model_management.archive_model_dtypes(connector_mod)
        log = (
            f"Q35 attach {os.path.basename(path)} tensors={len(conn_state)} "
            f"watch={list(off['layer_indices'])}"
        )
        logger.info(log)
        return (cloned, log)
