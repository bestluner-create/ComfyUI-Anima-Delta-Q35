from __future__ import annotations

import os
from pathlib import Path

from safetensors import safe_open
from safetensors.torch import save_file

import folder_paths

PREFIX = "net.anima_v2_connector."


def _diffusion_files():
    names = folder_paths.get_filename_list("diffusion_models")
    return sorted(n for n in names if n.lower().endswith(".safetensors")) or ["none"]


class AnimaQ35Extract:
    @classmethod
    def INPUT_TYPES(cls):
        return {
            "required": {
                "official_bundle": (_diffusion_files(),),
                "out_name": ("STRING", {"default": "anima_v2_connector_only.safetensors"}),
            }
        }

    RETURN_TYPES = ("STRING",)
    RETURN_NAMES = ("log",)
    FUNCTION = "extract"
    CATEGORY = "Anima Delta Mix"
    OUTPUT_NODE = True
    DESCRIPTION = "Cuts net.anima_v2_connector.* from official 1.1 into a sidecar."

    def extract(self, official_bundle, out_name):
        src = folder_paths.get_full_path("diffusion_models", official_bundle)
        if not src or not os.path.isfile(src):
            raise FileNotFoundError(official_bundle)
        tensors = {}
        meta = {}
        with safe_open(src, framework="pt", device="cpu") as f:
            meta = dict(f.metadata() or {})
            for k in f.keys():
                if k.startswith(PREFIX):
                    tensors[k] = f.get_tensor(k)
        if not tensors:
            raise RuntimeError(f"no {PREFIX}* in {official_bundle}")
        keep = {
            "architecture": "anima_v2_connector_sidecar",
            "anima_v2_connector_prefix": PREFIX,
            "source": official_bundle,
            "tensor_count": str(len(tensors)),
        }
        for k, v in meta.items():
            if k.startswith("anima_v2_"):
                keep[k] = str(v)
        out_name = Path(out_name.strip() or "anima_v2_connector_only.safetensors").name
        if not out_name.lower().endswith(".safetensors"):
            out_name += ".safetensors"
        dest = str(Path(src).resolve().parent / out_name)
        save_file(tensors, dest, metadata=keep)
        return (f"wrote {dest}\nconnector={len(tensors)}",)
