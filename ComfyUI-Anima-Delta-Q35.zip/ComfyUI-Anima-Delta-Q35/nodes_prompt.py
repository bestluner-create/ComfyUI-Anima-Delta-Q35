"""Thin prompt wrapper. Encode helpers and emit_conditioning come from the official MIT pack."""

from __future__ import annotations

import comfy.model_management

from .official_bridge import official_modules


class AnimaQ35Prompt:
    @classmethod
    def INPUT_TYPES(cls):
        return {
            "required": {
                "model": ("MODEL",),
                "native_clip": ("CLIP",),
                "qwen35_clip": ("CLIP",),
                "prompt": (
                    "STRING",
                    {"multiline": True, "dynamicPrompts": True},
                ),
            }
        }

    RETURN_TYPES = ("CONDITIONING", "CONDITIONING")
    RETURN_NAMES = ("expanded", "native")
    FUNCTION = "encode"
    CATEGORY = "Anima Delta Mix"
    DESCRIPTION = (
        "Encodes native 0.6B + Qwen 3.5 4B for a MODEL that already has anima_v2_connector."
    )

    @staticmethod
    def _unload(clip) -> None:
        comfy.model_management.unload_model_and_clones(
            clip.patcher,
            unload_additional_models=False,
            all_devices=True,
        )

    def encode(self, model, native_clip, qwen35_clip, prompt):
        off = official_modules()
        Prompt = off["prompt"].AnimaQwen35UnifiedPrompt
        emit = off["runtime"].emit_conditioning
        v2_arch = getattr(off["prompt"], "V2_ARCHITECTURE", None)
        if v2_arch is None:
            v2_arch = "anima_qwen35_quality_anchored_semantic_connector_v2"

        try:
            native = Prompt._encode_native(native_clip, prompt)
        finally:
            self._unload(native_clip)

        native_source, native_metadata = native[0]
        if native_source.ndim != 3 or native_source.shape[-1] != 1024:
            raise RuntimeError("native_clip must be Qwen3 0.6B.")
        if native_metadata.get("t5xxl_ids") is None:
            raise RuntimeError("Native conditioning has no T5 token IDs.")

        try:
            semantic_states, semantic_mask = Prompt._encode_semantic_layers(
                qwen35_clip, prompt
            )
        finally:
            self._unload(qwen35_clip)

        dit = getattr(model.model, "diffusion_model", None)
        native_adapter = getattr(dit, "llm_adapter", None)
        connector = getattr(dit, "anima_v2_connector", None)
        if native_adapter is None or connector is None:
            raise RuntimeError(
                "MODEL has no anima_v2_connector. Run DeltaMix Q35 Attach first."
            )

        path = getattr(connector, "_anima_v2_bundle_path", "q35-attach")
        return emit(
            expanded_adapter=connector,
            native_adapter=native_adapter,
            native=native,
            native_source=native_source,
            native_metadata=native_metadata,
            semantic_states=semantic_states,
            semantic_mask=semantic_mask,
            adapter_strength=1.0,
            architecture=v2_arch,
            checkpoint_path=path,
        )
