class PromptTextDelta:
    @classmethod
    def INPUT_TYPES(cls):
        return {
            "required": {
                "text": ("STRING", {"multiline": True, "default": ""}),
            },
            "optional": {
                "title": ("STRING", {"default": "Prompt"}),
            },
        }

    RETURN_TYPES = ("STRING",)
    RETURN_NAMES = ("text",)
    FUNCTION = "out"
    CATEGORY = "Anima Delta Mix/text"

    def out(self, text, title="Prompt"):
        return (text,)


class PromptDualDelta:
    @classmethod
    def INPUT_TYPES(cls):
        return {
            "required": {
                "quality_pos": ("STRING", {"multiline": True, "default": ""}),
                "quality_neg": ("STRING", {"multiline": True, "default": ""}),
                "common": ("STRING", {"multiline": True, "default": ""}),
            },
            "optional": {
                "separator": ("STRING", {"default": ", "}),
                "put_quality_first": ("BOOLEAN", {"default": True}),
            },
        }

    RETURN_TYPES = ("STRING", "STRING")
    RETURN_NAMES = ("pos", "neg")
    FUNCTION = "build"
    CATEGORY = "Anima Delta Mix/text"
    DESCRIPTION = "pos = quality_pos + common. neg = quality_neg only."

    def build(
        self,
        quality_pos,
        quality_neg,
        common,
        separator=", ",
        put_quality_first=True,
    ):
        sep = separator if separator is not None else ""
        q = (quality_pos or "").strip()
        body = (common or "").strip()
        if q and body:
            pos = f"{q}{sep}{body}" if put_quality_first else f"{body}{sep}{q}"
        else:
            pos = q or body
        return (pos, (quality_neg or "").strip())
