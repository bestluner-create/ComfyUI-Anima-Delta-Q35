"""Locate GumGum10/comfyui-anima-3-8B at runtime. Import only — do not vendor source."""

from __future__ import annotations

import importlib
import importlib.util
import inspect
import sys
from pathlib import Path

_CACHE = {}


def _is_connector_class(obj) -> bool:
    return inspect.isclass(obj) and obj.__name__ == "QualityAnchoredSemanticConnectorV2"


def _pack(cls, conn, runtime, prompt, v2, pkg):
    return {
        "connector_cls": cls,
        "v2": v2,
        "runtime": runtime,
        "prompt": prompt,
        "layer_indices": getattr(conn, "LAYER_INDICES", (7, 15, 23, 31)),
        "pkg": pkg,
    }


def official_modules():
    if _CACHE:
        return _CACHE

    for name, mod in list(sys.modules.items()):
        if not str(name).endswith("semantic_connector_v2"):
            continue
        cls = getattr(mod, "QualityAnchoredSemanticConnectorV2", None)
        if not _is_connector_class(cls):
            continue
        prefix = name[: -len("semantic_connector_v2")].rstrip(".")
        runtime = sys.modules.get(f"{prefix}.semantic_v2_runtime")
        prompt = sys.modules.get(f"{prefix}.prompt")
        if runtime is None or not hasattr(runtime, "emit_conditioning"):
            continue
        if prompt is None:
            continue
        _CACHE.update(_pack(cls, mod, runtime, prompt, sys.modules.get(f"{prefix}.v2"), prefix or name))
        return _CACHE

    roots = []
    p = Path(__file__).resolve()
    for parent in p.parents:
        cn = parent / "custom_nodes"
        if cn.is_dir():
            roots.append(cn)
            break
    roots.append(Path(r"A:/ComfyUI_windows_portable/ComfyUI/custom_nodes"))

    for cn in roots:
        if not cn.is_dir():
            continue
        for hit in cn.glob("*/semantic_connector_v2.py"):
            root = hit.parent
            root_s = str(root)
            if root_s not in sys.path:
                sys.path.insert(0, root_s)
            try:
                conn = importlib.import_module("semantic_connector_v2")
                runtime = importlib.import_module("semantic_v2_runtime")
                prompt = importlib.import_module("prompt")
                try:
                    v2 = importlib.import_module("v2")
                except ImportError:
                    v2 = None
            except Exception:
                continue
            cls = getattr(conn, "QualityAnchoredSemanticConnectorV2", None)
            if not _is_connector_class(cls) or not hasattr(runtime, "emit_conditioning"):
                continue
            _CACHE.update(_pack(cls, conn, runtime, prompt, v2, root.name))
            return _CACHE

    raise RuntimeError(
        "comfyui-anima-3-8B is not loaded. Install GumGum10/comfyui-anima-3-8B (MIT)."
    )
